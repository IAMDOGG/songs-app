<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Song;
use Illuminate\Support;
use Illuminate\Support\Facades\Validator;
class SongController extends Controller
{
    public function viewSongs(){
        $song = Song::all();
        if($song->count() > 0){
        return response()->json([
            "status" => 200,
            "songs" => $song
            
        ]);
    }
    else{
    return response()->json([
        "status" => 400,
        "message" => "Songs not found"
    ],404);
    }
}
    public function addSong(Request $request){
        $validator = Validator::make($request->all(),[
            'song_name' => 'required|string|max:191',
            'author_name' => 'required|string|max:191',
            'releaser_year' => 'required|digits:4'
        ]);
        if($validator->fails()){
            return response()->json([    
            "status" => 422,
            "message" => $validator->messages()
            ],422);
        }
        else{
            $song = Song::create([
                   'song_name' => $request->song_name,
                    'author_name' => $request->author_name,  
                    'releaser_year' => $request->releaser_year   
            ]);
            if($song){
                return response()->json([    
                    "status" => 200,
                    "message" => "Successfully added Song!"
                    ],200);
            }
            else{
                return response()->json([    
                    "status" => 400,
                    "message" => "Invalid Input!"
                    ],400);
            }
    }
    }
    public function viewSpecificSong($id){
        $song = Song::find($id);
        if($song){
            return response()->json([
                "status" => 200,
                "songs" => $song
                
            ]);
        }
        else{
            return response()->json([
                "status" => 400,
                "message" => "Songs not found"
            ],404);
        }
    }
    public function editSong($id, Request $request){
        $validator = Validator::make($request->all(),[
            'song_name' => 'required|string|max:191',
            'author_name' => 'required|string|max:191',
            'releaser_year' => 'required|digits:4'
        ]);
        $song = Song::find($id);
        if($validator->fails()){
            return response()->json([    
            "status" => 422,
            "message" => $validator->messages()
            ],422);
        }
        else{
            $song->update([
                   'song_name' => $request->song_name,
                    'author_name' => $request->author_name,  
                    'releaser_year' => $request->releaser_year   
            ]);
            if($song){
                return response()->json([    
                    "status" => 200,
                    "message" => "Successfully added Song!"
                    ],200);
            }
            else{
                return response()->json([    
                    "status" => 400,
                    "message" => "Invalid Input!"
                    ],400);
            }
    }
    }
    public function deleteSong($id){
        $song = Song::find($id);
        if($song){
            $song->delete();
            return response()->json([    
                "status" => 200,
                "message" => "Successfully deleted Song!"
                ],200);
        }
        else{
            return response()->json([    
                "status" => 400,
                "message" => "Invalid Input!"
                ],400);
        }
        }
    }

